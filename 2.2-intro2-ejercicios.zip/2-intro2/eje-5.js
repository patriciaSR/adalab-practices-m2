'use strict';

const age = 26;
const day = 24;
const year = 365;

const yearHours = day * year;
console.log(`Un año tiene ${yearHours} horas`);

const totalHours = yearHours * age;
console.log(`He vivido ${totalHours} horas`);
  