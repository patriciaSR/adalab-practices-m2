'use strict';

const pera = 2;
const kiwi = 5;
const uva = 4;

console.log(3 * pera + 2 * kiwi + uva / 2);
